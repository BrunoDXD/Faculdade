﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho_15_11
{
    public class Consumo : Atividades
    {
        public string Descricao { get; set; }
        public double Valor { get; set; }
        public double ValorFinal { get; set; }

        public Consumo(string n, string l, string d, string h) : base(n, l, d, h)
        {
            this.Nome = n;
            this.Local = l;
            this.Data = d;
            this.Hora = h;
        }

        public override double Calcula => this.ValorFinal += this.Valor;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabalho_15_11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Consumo a = new Consumo("","","","");
        List<Consumo> Atividade = new List<Consumo>();
        List<string> Produtos = new List<string>();
        List<double> precos = new List<double>();
        double calcula = 0;

        

        private void btncriar_Click(object sender, EventArgs e)
        {
            calcula = 0;
            a.ValorFinal = 0;
            Produtos = new List<string>();
            precos = new List<double>();
            Atividade.Add(new Consumo(a.Nome = txtnome.Text, a.Local = txtlocal.Text, a.Data = txtdata.Text, a.Hora = txthora.Text));              
            txtnome.Text = "";
            txtdata.Text = "";
            txtlocal.Text = "";
            txthora.Text = "";
            
        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
            bool b = false;
            for(int i = 0; i < Atividade.Count; i++)
            {
                if(txtnome.Text == Atividade[i].Nome) 
                {
                    txtlocal.Text = Atividade[i].Local;
                    txtdata.Text = Atividade[i].Data;
                    txthora.Text = Atividade[i].Hora;
                    b = true;
                }
            }
            if (b != true)  MessageBox.Show("Nenhum resultado encontrado");
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnome.Text = "";
            txtlocal.Text = "";
            txtdata.Text = "";
            txthora.Text = "";
        }
        private void btnencerrar_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Atividade.Count; i++)
            {
                if (txtnome.Text == a.Nome)
                {
                    txtnome.Text = "";
                    txtlocal.Text = "";
                    txtdata.Text = "";
                    txthora.Text = "";
                    Produtos[i] = "";
                    precos[i] = 0;

                }
            }
        }

        private void btnadicionar_Click(object sender, EventArgs e)
        {
            
            a.Valor = Convert.ToDouble(txtvalor.Text);
            calcula = a.Calcula;
            Produtos.Add(txtdescricao.Text);
            precos.Add(Convert.ToDouble(txtvalor.Text));
            txtdescricao.Text = "";
            txtvalor.Text = "";
            
        }

        private void btnmostrar_Click(object sender, EventArgs e)
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine("Produto         Preço");

            for (int j = 0; j < Produtos.Count; j++)
            {
                stringBuilder.AppendLine($"{Produtos[j]}         {precos[j].ToString("C")}");
            }
            for (int i = 0; i < Atividade.Count; i++)
            {
                if (txtnome.Text == Atividade[i].Nome)
                {
                    MessageBox.Show($"Nome: {Atividade[i].Nome}\t\tLocal: {Atividade[i].Local}\nData: {Atividade[i].Data}" +
                        $"\t\tHora: {Atividade[i].Hora}\n\n {stringBuilder.ToString()}\n\n Total:     {a.ValorFinal.ToString("C")} ");
                }
            }
            
        }

        
    }
}

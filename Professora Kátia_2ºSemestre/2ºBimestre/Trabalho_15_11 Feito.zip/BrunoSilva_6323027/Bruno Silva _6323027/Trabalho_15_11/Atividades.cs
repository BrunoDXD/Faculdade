﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho_15_11
{
    public abstract class Atividades
    {
        public string Nome { get; set; }
        public string Local { get; set; }
        public string Data { get; set; }
        public string Hora { get; set; }

        public Atividades(string n, string l, string d, string h)
        {
            this.Nome = n;
            this.Local = l;
            this.Data = d;
            this.Hora = h;
        }
        public abstract double Calcula { get; }
       
    }
}
